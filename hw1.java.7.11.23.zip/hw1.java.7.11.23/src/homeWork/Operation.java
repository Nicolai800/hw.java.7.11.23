package homeWork;

public class Operation {
    private  Operation(){
    }
    public static int addAll(int... numb){
    int summ = 0;
        for (int i = 0; i < numb.length; i++) {
          summ = summ+ numb[i];
        }
        return summ;
    }
    public static int minusAll(int n, int... numb){
        int result = n;
        for (int i = 0; i < numb.length; i++) {
            result = result - numb[i];

        }
        return result;
    }
    public static int multAll(int... numb){
        int mult = 1;
        for (int i = 0; i <numb.length; i++) {
           mult = mult*numb[i];
        }
        return mult;
    }
    public static int powAll(int first, int... numb){
        int pow = first;
        for (int i:
             numb) {
            pow = (int) Math.pow(pow,i);

        }
        return pow;

        }


    }


