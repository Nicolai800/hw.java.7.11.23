import homeWork.Operation;

public class Main {
    public static void main(String[] args) {
        System.out.println("addAll = " + Operation.addAll(1,2,3,4,5));
        System.out.println("minusAll = " + Operation.minusAll(100, 23,7,50));
        System.out.println("multAll = " + Operation.multAll(3,2,10));
        System.out.println("powAll = " + Operation.powAll(3,7,12,3));
    }
}
/*Создайте утилитарный класс, который будет аналогом класса Math.
В нём будет один приватный конструктор, а также только статические методы:
addAll - сложение неограниченного числа аргументов
minusAll – принимает исходное число и неограниченный набор аргументов, которые нужно вычесть из исходного числа
multAll – перемножает все данные аргументы
powAll – принимает исходное число-основание и неограниченный набор аргументов степеней.
Нужно последовательно возвести основание во все степени.
Используйте все методы в коде метода main.*/