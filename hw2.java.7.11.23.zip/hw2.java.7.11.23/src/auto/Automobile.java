package auto;

public class Automobile {
    public String brand;
    public String color;
    public double weight;
    public double length;
    public int topSpeed;

    public Automobile(String color, double weight, double length, int topSpeed, String transmission, String brand) {
        this.brand = brand;
        this.color = color;
        this.weight = weight;
        this.length = length;
        this.topSpeed = topSpeed;
        this.transmission = transmission;
    }

    public String transmission;

    @Override
    public String toString() {
        return "Automobile{" +
                "brand='" + brand + '\'' +
                ", color='" + color + '\'' +
                ", weight=" + weight +
                ", length=" + length +
                ", topSpeed=" + topSpeed +
                ", transmission='" + transmission + '\'' +
                '}';
    }
}
